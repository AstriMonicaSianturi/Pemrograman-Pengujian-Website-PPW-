<!DOCTYPE html>
<html lang="en">

<head>
        <title>Contact</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <a class="navbar-brand" href="index.php">Contact</a>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
            <a class="nav-link" href="/list">List Contact</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="/new">New Contact</a>
        </li>
                <li class="nav-item active">
            <a class="nav-link" href="/contact">Favorite</a>
        </li>
                <li class="nav-item active">
            <a class="nav-link" href="/favorite">Block</a>
        </li>
            </ul>
</nav>

    
    <div class="container text-center" style="margin-top:20px">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <form>
                <img width="150px" src="images\logoo.jpg">
                <h3 class="h3 mb-3 font-weight-normal">Contact-in Aja</h3>
                <div class="form-group">
                    <input type="text" name="name" class="form-control" placeholder="No Telepon" required autofocus>
                </div>
               
                <div class="row">
                    <div class="col-md-12">
                        <button href ="list-contact.php" class="btn btn-sm btn-primary btn-block" type="submit">Login</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
<script src="js/jquery.min.js"></script>
<script>

</script>
</html><?php /**PATH C:\Laravel Project\installlaravel1_1\resources\views/contact-detail.blade.php ENDPATH**/ ?>