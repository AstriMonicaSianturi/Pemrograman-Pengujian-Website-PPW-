
<!DOCTYPE html>
<html lang="en">

<head>
        <title>Contact</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <a class="navbar-brand" href="list-contact">Contact</a>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
            <a class="nav-link" href="/list">List Contact</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="/new">New Contact</a>
        </li>
                <li class="nav-item active">
            <a class="nav-link" href="/contact">Favorite</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="/favorite">Block</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="/">Exit</a>
        </li>

            </ul>
</nav>

    <div class="container">
    <h1 class="text-center">Block
    </h1>
    
    <div class="row">
        <div class="col-md-10 offset-md-1">
            <table class="table">
                <thead>
                    <tr>
                        <th>List Block Contact</th>  
                    </tr>
                    <tr>
                        <th> 
                            <input class="search" type="search" placeholder="Search...">               
                            <input class="button" type="submit" value="Search">       
                        </th>            
                           
                               
                            </body>
                         <th>Add Contact</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    

</body>

</html><?php /**PATH C:\xampp\htdocs\installlaravel1_1\resources\views/block.blade.php ENDPATH**/ ?>