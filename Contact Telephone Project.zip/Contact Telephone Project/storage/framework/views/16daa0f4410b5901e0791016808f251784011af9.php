<!DOCTYPE html>
<html lang="en">

<head>
        <title>Contact</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
</head>

<body>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <a class="navbar-brand" href="#">Contact</a>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
            <a class="nav-link" href="/list">List Contact</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="/new">New Contact</a>
        </li>
                <li class="nav-item active">
            <a class="nav-link" href="/contact">Favorite</a>
        </li>
                <li class="nav-item active">
            <a class="nav-link" href="/">Block</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="/">Exit</a>
        </li>
            </ul>
</nav>

    <div class="container">
    <h1 class="text-center">Detail Contact</h1>
    <div class="row">
        <div class="col-md-10 offset-md-1">
            <table class="table" id="table">
            </table>
        </div>
    </div>
</div>

</body>

<script>
var url = window.location.pathname;
var id = url.split('/');
var temp = id[id.length-1];
$.ajax({
    url:'http://localhost:8000/api/get_detail/' + temp,
    type:'GET',
    success:function(e){
        var htmls='';
        htmls+='<tr>';
        htmls+='<td>Contact Number<td><td>:<td>'
        htmls+='<td>'+e.data.no_handphone+'<td>'
        htmls+='</tr>';

        htmls+='<tr>';
        htmls+='<td>Name<td><td>:<td>'
        htmls+='<td>'+e.data.name+'<td>'
        htmls+='</tr>';

        htmls+='<tr>';
        htmls+='<td>Address<td><td>:<td>'
        htmls+='<td>'+e.data.address+'<td>'
        htmls+='</tr>';

        htmls+='<tr>';
        htmls+='<td>Email<td><td>:<td>'
        htmls+='<td>'+e.data.email+'<td>'
        htmls+='</tr>';

        $('#table').append(htmls);
    }
});
</script>
</html>
<?php /**PATH C:\xampp\htdocs\installlaravel1\resources\views/detail_contact.blade.php ENDPATH**/ ?>